import modelo.Reserva;
import original.ReservaServiceOriginal;
import refatorada.*;

/** Ponto de entrada: executa e compara as duas versões. Ver README.md. */
public class Main {

    public static void main(String[] args) {
        // Os mesmos objetos de entrada são usados nas duas versões.
        Reserva[] solicitacoes = {
            new Reserva("A101", 10, 12, "aluna@universidade.br"),
            new Reserva("A101", 7, 9, "aluna@universidade.br"),
            new Reserva("A101", 10, 10, "aluna@universidade.br"),
            new Reserva(" ", 10, 12, "aluna@universidade.br")
        };

        System.out.println("=== 1. VERSÃO ORIGINAL ACOPLADA ===");
        System.out.println("Regra fixa: sala comum, das 8h às 18h.");
        ReservaServiceOriginal original = new ReservaServiceOriginal();
        for (Reserva r : solicitacoes) {
            System.out.println("\nSolicitação: " + descrever(r));
            try {
                String codigo = original.reservar(r);
                System.out.println("Código devolvido: " + codigo);
            } catch (IllegalArgumentException | IllegalStateException e) {
                System.out.println(e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        }

        System.out.println("\n=== 2. VERSÃO REFATORADA COM SOLID ===");
        System.out.println("Mesma regra de sala comum e mesmas solicitações.");
        RepositorioMemoria repositorio = new RepositorioMemoria();
        ReservaService refatorada = new ReservaService(
                new PoliticaSalaComum(), repositorio, new EmailNotificador());
        for (Reserva r : solicitacoes) {
            System.out.println("\nSolicitação: " + descrever(r));
            try {
                String codigo = refatorada.reservar(r);
                System.out.println("Código devolvido: " + codigo);
            } catch (IllegalArgumentException | IllegalStateException e) {
                System.out.println(e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        }

        System.out.println("\n=== 3. EXTENSÕES NA COMPOSIÇÃO ===");
        System.out.println("Laboratório com outro canal, mantendo ReservaService.");
        ReservaService laboratorio = new ReservaService(
                new PoliticaLaboratorio(), repositorio, new ConsoleNotificador());
        // Fronteiras inclusivas: o laboratório permite exatamente 10h–16h.
        String codigoLaboratorio = laboratorio.reservar(
                new Reserva("LAB01", 10, 16, "docente@universidade.br"));
        System.out.println("Código do laboratório: " + codigoLaboratorio);

        System.out.println("\nSala de estudos com uma nova política.");
        ReservaService estudos = new ReservaService(
                new PoliticaSalaEstudos(), repositorio, new ConsoleNotificador());
        String codigoEstudos = estudos.reservar(
                new Reserva("EST01", 7, 9, "aluna@universidade.br"));
        System.out.println("Código da sala de estudos: " + codigoEstudos);

        System.out.println("\n=== 4. CONTRATO DAS POLÍTICAS (LSP) ===");
        Reserva horarioComparado = new Reserva("A101", 9, 11, "aluna@universidade.br");
        // Dados válidos. Cada política decide; todas retornam um booleano.
        PoliticaReserva[] politicas = {
            new PoliticaSalaComum(),
            new PoliticaLaboratorio(),
            new PoliticaSalaEstudos()
        };
        for (PoliticaReserva politica : politicas) {
            System.out.println(politica.getClass().getSimpleName()
                    + ", 9h–11h: " + politica.permite(horarioComparado));
        }
        System.out.println("false é uma recusa prevista pelo contrato da política.");
        System.out.println("O serviço transforma essa recusa em uma exceção:");
        try {
            laboratorio.reservar(horarioComparado);
        } catch (IllegalStateException e) {
            System.out.println(e.getClass().getSimpleName() + ": " + e.getMessage());
        }

        System.out.println("\n=== 5. CLIENTES COM INTERFACES ESPECÍFICAS (ISP) ===");
        // Mesma instância: serviço, consulta e cancelamento compartilham o mapa.
        PortalConsulta consulta = new PortalConsulta(repositorio);
        System.out.println("Consulta de " + codigoLaboratorio + ": "
                + consulta.mostrarSala(codigoLaboratorio));
        // O repositório atende ao contrato de cancelamento sem expor seu mapa.
        CancelamentoReserva cancelamento = repositorio;
        cancelamento.cancelar(codigoLaboratorio);
        System.out.println("Depois do cancelamento: "
                + consulta.mostrarSala(codigoLaboratorio));
        System.out.println("Sala de estudos continua registrada: "
                + consulta.mostrarSala(codigoEstudos));
    }

    private static String descrever(Reserva r) {
        return "sala='" + r.getSala() + "', " + r.getInicio() + "h–" + r.getFim() + "h";
    }
}
