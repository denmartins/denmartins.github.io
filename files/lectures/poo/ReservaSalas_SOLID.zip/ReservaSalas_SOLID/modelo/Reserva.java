package modelo;


/** Dados imutáveis da solicitação, compartilhados pelas duas versões. */
public class Reserva {
    private final String sala;
    private final int inicio;
    private final int fim;
    private final String contato;

    public Reserva(String sala, int inicio, int fim, String contato) {
        this.sala = sala;
        this.inicio = inicio;
        this.fim = fim;
        this.contato = contato;
    }

    public String getSala() { return sala; }

    public int getInicio() { return inicio; }

    public int getFim() { return fim; }

    public String getContato() { return contato; }
}
