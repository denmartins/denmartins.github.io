package refatorada;

import modelo.Reserva;

/** SRP: concentra a apresentação da confirmação. */
public class FormatadorConfirmacao {
    public String formatar(String codigo, Reserva r) {
        return "Reserva " + codigo + " | Sala: " + r.getSala()
                + " | Horário: " + r.getInicio() + "-" + r.getFim();
    }
}
