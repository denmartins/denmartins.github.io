package refatorada;


/** Simula envio por e-mail imprimindo no console. */
public class EmailNotificador implements Notificador {
    @Override
    public void enviar(String destino, String mensagem) {
        System.out.println("EMAIL " + destino + ": " + mensagem);
    }
}
