package refatorada;

import modelo.Reserva;

/** Cliente que depende apenas de ConsultaReserva. */
public class PortalConsulta {
    private final ConsultaReserva reservas;

    public PortalConsulta(ConsultaReserva reservas) {
        this.reservas = reservas;
    }

    public String mostrarSala(String codigo) {
        Reserva r = reservas.consultar(codigo);
        return r == null ? "Reserva não encontrada" : r.getSala();
    }
}
