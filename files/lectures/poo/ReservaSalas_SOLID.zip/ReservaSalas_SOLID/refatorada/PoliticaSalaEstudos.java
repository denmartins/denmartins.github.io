package refatorada;

import modelo.Reserva;

/** Política de estudos: 6h–22h, limites inclusivos. */
public class PoliticaSalaEstudos implements PoliticaReserva {
    @Override
    public boolean permite(Reserva r) {
        return r.getInicio() >= 6 && r.getFim() <= 22;
    }
}
