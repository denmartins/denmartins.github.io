package refatorada;

import modelo.Reserva;

/** ISP: contrato usado pelo serviço para registrar reservas. */
public interface RegistroReserva {
    // Registra a reserva válida e devolve um código não vazio.
    String salvar(Reserva r);
}
