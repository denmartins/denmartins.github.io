package refatorada;

import modelo.Reserva;

/** Política de sala comum: 8h–18h, limites inclusivos. */
public class PoliticaSalaComum implements PoliticaReserva {
    @Override
    public boolean permite(Reserva r) {
        return r.getInicio() >= 8 && r.getFim() <= 18;
    }
}
