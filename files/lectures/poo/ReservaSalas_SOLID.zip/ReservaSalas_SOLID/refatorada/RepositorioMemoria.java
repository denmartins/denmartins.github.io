package refatorada;

import modelo.Reserva;
import java.util.Map;
import java.util.HashMap;

/** Armazenamento compartilhado pelos clientes por contratos específicos. */
public class RepositorioMemoria
        implements RegistroReserva, ConsultaReserva, CancelamentoReserva {
    private final Map<String, Reserva> dados = new HashMap<>();
    private int sequencia = 0;

    @Override
    public String salvar(Reserva r) {
        String codigo = "RES-" + (++sequencia);
        dados.put(codigo, r);
        return codigo;
    }

    @Override
    public Reserva consultar(String codigo) {
        return dados.get(codigo);
    }

    @Override
    public void cancelar(String codigo) {
        dados.remove(codigo);
    }
}
