package refatorada;

import modelo.Reserva;

/** Política de laboratório: 10h–16h, limites inclusivos. */
public class PoliticaLaboratorio implements PoliticaReserva {
    @Override
    public boolean permite(Reserva r) {
        return r.getInicio() >= 10 && r.getFim() <= 16;
    }
}
