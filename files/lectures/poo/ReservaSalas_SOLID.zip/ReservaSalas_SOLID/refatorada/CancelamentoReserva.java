package refatorada;


/** ISP: contrato para cancelar reservas. */
public interface CancelamentoReserva {
    // Remove o registro. Código inexistente não produz efeito.
    void cancelar(String codigo);
}
