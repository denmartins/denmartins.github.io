package refatorada;

import modelo.Reserva;

/** OCP e LSP: recebe reserva não nula, aprovada pelo validador. Para toda entrada válida, retorna true ou false, sem exceções nem efeitos externos. */
public interface PoliticaReserva {
    boolean permite(Reserva r);
}
