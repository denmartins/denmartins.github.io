package refatorada;


/** DIP: contrato de comunicação definido pela necessidade da aplicação. */
public interface Notificador {
    void enviar(String destino, String mensagem);
}
