package refatorada;


/** Simula outro canal, imprimindo com o prefixo AVISO. */
public class ConsoleNotificador implements Notificador {
    @Override
    public void enviar(String destino, String mensagem) {
        System.out.println("AVISO " + destino + ": " + mensagem);
    }
}
