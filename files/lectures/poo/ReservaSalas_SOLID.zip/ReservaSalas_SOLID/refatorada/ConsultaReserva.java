package refatorada;

import modelo.Reserva;

/** ISP: contrato usado pelo portal para consultar reservas. */
public interface ConsultaReserva {
    // Retorna a reserva, ou null se o código não estiver registrado.
    Reserva consultar(String codigo);
}
