package refatorada;

import modelo.Reserva;

/** SRP: verifica dados obrigatórios e intervalo. Aceita somente dados válidos. */
public class ValidadorReserva {
    public void validar(Reserva r) {
        if (r == null || r.getSala() == null || r.getSala().trim().isEmpty()
                || r.getContato() == null || r.getContato().trim().isEmpty()
                || r.getInicio() < 0 || r.getInicio() >= r.getFim() || r.getFim() > 24) {
            throw new IllegalArgumentException("Dados inválidos");
        }
    }
}
