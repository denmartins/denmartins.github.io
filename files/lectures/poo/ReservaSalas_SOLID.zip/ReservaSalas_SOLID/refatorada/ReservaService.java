package refatorada;

import modelo.Reserva;

/** Coordena o caso de uso. Depende das abstrações de política, registro e notificação. */
public class ReservaService {
    private final ValidadorReserva validador = new ValidadorReserva();
    private final FormatadorConfirmacao formatador = new FormatadorConfirmacao();
    private final PoliticaReserva politica;
    private final RegistroReserva repositorio;
    private final Notificador notificador;

    public ReservaService(PoliticaReserva politica, RegistroReserva repositorio,
                   Notificador notificador) {
        this.politica = politica;
        this.repositorio = repositorio;
        this.notificador = notificador;
    }

    public String reservar(Reserva r) {
        validador.validar(r);
        if (!politica.permite(r)) {
            throw new IllegalStateException("Horário não permitido");
        }
        String codigo = repositorio.salvar(r);
        String mensagem = formatador.formatar(codigo, r);
        notificador.enviar(r.getContato(), mensagem);
        return codigo;
    }
}
