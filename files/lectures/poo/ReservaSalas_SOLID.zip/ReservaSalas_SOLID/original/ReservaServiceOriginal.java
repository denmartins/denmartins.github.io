package original;

import modelo.Reserva;
import java.util.Map;
import java.util.HashMap;

/** Versão acoplada: validação, horário, armazenamento e envio na mesma classe. */
public class ReservaServiceOriginal {
    private final Map<String, Reserva> dados = new HashMap<>();
    private int sequencia = 0;

    public String reservar(Reserva r) {
        if (r == null || r.getSala() == null || r.getSala().trim().isEmpty()
                || r.getContato() == null || r.getContato().trim().isEmpty()
                || r.getInicio() < 0 || r.getInicio() >= r.getFim() || r.getFim() > 24) {
            throw new IllegalArgumentException("Dados inválidos");
        }
        if (r.getInicio() < 8 || r.getFim() > 18) {
            throw new IllegalStateException("Horário não permitido");
        }
        String codigo = "RES-" + (++sequencia);
        dados.put(codigo, r);
        System.out.println("EMAIL " + r.getContato() + ": reserva " + codigo);
        return codigo;
    }
}
