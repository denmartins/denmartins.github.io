# Sistema de reserva de salas: aula de Princípios SOLID

Projeto Java com uma classe ou interface por arquivo e organização em pacotes. O ponto de entrada **Main.java está na raiz**, sem declaração de pacote.

A extensão `.java` em minúsculas é necessária para a compilação padrão. O nome da classe pública é `Main`.

## Execução

Requisito: JDK 8 ou superior. Abra o terminal na pasta onde está `Main.java`.

```bash
javac -encoding UTF-8 -d out Main.java
java -cp out Main
```

O compilador encontra os demais arquivos pelos pacotes. Se usar uma IDE, abra a pasta inteira como projeto Java, usando a raiz como pasta de fontes e `Main` como classe de execução. Não abra apenas o arquivo isolado.

## Organização

| Caminho | Conteúdo |
|---|---|
| `Main.java` | Execução da versão acoplada, da refatorada e das extensões |
| `modelo/` | Dados da reserva |
| `original/` | Serviço original com responsabilidades concentradas |
| `refatorada/` | Serviço, colaboradores, políticas e contratos SOLID |
| `SAIDA_ESPERADA.txt` | Saída gerada pela execução verificada |

## Percurso sugerido para a aula

1. Ler `modelo/Reserva.java` e `original/ReservaServiceOriginal.java`.
2. Examinar a separação de validação, formatação, armazenamento e comunicação (SRP).
3. Comparar as três implementações de `PoliticaReserva` (OCP).
4. Conferir o contrato booleano: toda reserva válida recebe uma decisão, mesmo quando o horário é recusado (LSP).
5. Comparar os contratos de registro, consulta e cancelamento e a dependência do portal (ISP).
6. Observar o construtor de `ReservaService` e as escolhas concretas em `Main` (DIP).

O `main` usa os mesmos objetos de entrada para comparar as duas versões. Depois demonstra laboratório, sala de estudos, troca de notificador, consulta e cancelamento. A versão original mantém a confirmação curta. A versão refatorada incorpora a confirmação detalhada prevista no exercício de SRP.

Os campos de `Reserva` são privados e finais, com getters, para permitir o uso entre pacotes mantendo o encapsulamento. As classes e operações usadas entre pacotes são públicas.

## Premissas

Sala e contato preenchidos; `0 <= inicio < fim <= 24`. Sala comum: 8h–18h; laboratório: 10h–16h; estudos: 6h–22h. As fronteiras são inclusivas. A aplicação escolhe a política: não há inferência pelo identificador da sala.

Armazenamento em memória e comunicação simulada no console. Não há datas, conflitos de agenda, concorrência, autenticação ou transação entre salvar e enviar. Os códigos são sequenciais por instância de repositório.

As demandas de sala de reunião, duração na confirmação, `PainelNotificador` e `PortalCancelamento` permanecem como atividade extraclasse do roteiro.
